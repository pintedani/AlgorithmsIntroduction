def bubble_sort(arr):
    #Implement method
    return 0

# Usage example
arr = [64, 34, 25, 12, 22, 11, 90]
bubble_sort(arr)
print("Sorted array is:", arr)
