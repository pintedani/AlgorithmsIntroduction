def binary_search(arr, target):
    #Implement method
    return 0

# Usage example
sorted_list = [1, 8, 13, 26, 44, 48, 59]
target = 48
result = binary_search(sorted_list, target)
if result != -1:
    print(f"Target {target} found at index {result}.")
else:
    print(f"Target {target} not found in the list.")