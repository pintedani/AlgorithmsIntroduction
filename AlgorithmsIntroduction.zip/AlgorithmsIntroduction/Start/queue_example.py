class Queue:
    def __init__(self):
        self.items = []
        
    def enqueue(self, item):
        #Implement method
        return 0
        
    def dequeue(self):
        #Implement method
        return 0
        
# Usage example
queue = Queue()
queue.enqueue(3)
queue.enqueue(4)
queue.enqueue(5)

print(queue.dequeue())
print(queue.dequeue())
print(queue.dequeue())
        
