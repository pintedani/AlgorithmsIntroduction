def count_values(list):
    #Implement method
    return 0

# Usage example
color_list = ["red", "blue", "red", "green", "blue", "red", "red"]

color_counts = count_values(color_list)
print("Value counts: ", color_counts)