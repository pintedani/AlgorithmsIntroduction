array = [2, 13, 25, 8]
    # get element by index