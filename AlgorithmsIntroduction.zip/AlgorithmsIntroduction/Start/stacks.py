class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        #Implement method
        return 0

    def pop(self):
        #Implement method
        return 0

# Usage example
stack = Stack()
stack.push(3)
stack.push(4)
stack.push(5)

print(stack.pop())
print(stack.pop())
print(stack.pop())
