class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
        
class LinkedList:
    def __init__(self):
        self.head = None
        
    def insertAtBegin(self, data):
        #Implement method
        return 0
            
    def print(self):
        #Implement method
        return 0
        
# Usage example
linkedList = LinkedList()
linkedList.insertAtBegin(2)
linkedList.insertAtBegin(10)
linkedList.insertAtBegin(5)
linkedList.print()