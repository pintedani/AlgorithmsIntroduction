array = [2, 13, 25, 8]
print(array[1])